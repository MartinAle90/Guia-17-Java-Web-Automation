package com.wa_2part;

public class AppTest {
}
