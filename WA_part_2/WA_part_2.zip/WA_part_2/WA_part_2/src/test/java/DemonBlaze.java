import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.time.Duration;

public class DemonBlaze {

    WebDriver driver = null;


    @Test
    public void testDemonBlaze() {
        String driverPath = "D:/Cursos/Egg - Globant - QA/10-09-2023 - Guia 17 - Web Automation/Ejercicios/WebDriverChrome/chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.navigate().to("https://demoblaze.com/index.html");

        WebElement singup = driver.findElement(By.cssSelector("#signin2"));
        singup.click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));

        WebElement username = driver.findElement(By.cssSelector("#sign-username"));
        username.click();
        username.sendKeys("a");
        WebElement password = driver.findElement(By.cssSelector("#sign-password"));
        password.click();
        password.sendKeys("a");

        WebElement clicButton = driver.findElement(By.cssSelector("body.modal-open:nth-child(2) div.modal.fade.show:nth-child(2) div.modal-dialog div.modal-content div.modal-footer > button.btn.btn-primary:nth-child(2)"));
//        WebElement signUpButt = driver.findElement(By.cssSelector("body.modal-open:nth-child(2) div.modal.fade.show:nth-child(2) div.modal-dialog div.modal-content div.modal-footer > button.btn.btn-primary:nth-child(2)\n"));
        clicButton.click();


        driver.close();

    }


}
